#!/bin/bash
# Roblox游戏发布前检查清单
# 确保每次更新发布的质量和稳定性

echo "=== Roblox游戏发布前检查清单 ==="
echo "版本: 1.0.0"
echo ""

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 初始化检查结果
passed=0
failed=0
warnings=0

# 检查函数
check_item() {
    local description="$1"
    local command="$2"
    local required="$3" # "required" 或 "optional"
    
    echo -n "检查: $description ... "
    
    if eval "$command" > /dev/null 2>&1; then
        echo -e "${GREEN}✓ 通过${NC}"
        ((passed++))
        return 0
    else
        if [ "$required" = "required" ]; then
            echo -e "${RED}✗ 失败（必需）${NC}"
            ((failed++))
            return 1
        else
            echo -e "${YELLOW}⚠️  警告（可选）${NC}"
            ((warnings++))
            return 2
        fi
    fi
}

# 1. 基础检查
echo -e "${BLUE}1. 基础配置检查${NC}"
echo "----------------------------------------"

check_item "版本号已更新" "grep -q 'version.*[0-9]' *.lua 2>/dev/null || grep -q 'Version.*[0-9]' *.txt 2>/dev/null" "required"
check_item "更新日志已编写" "test -f CHANGELOG.md || test -f changelog.txt || test -f update-notes.txt" "required"
check_item "README文件存在" "test -f README.md" "optional"

# 2. 代码质量检查
echo -e "\n${BLUE}2. 代码质量检查${NC}"
echo "----------------------------------------"

check_item "无语法错误" "find . -name '*.lua' -exec luac -p {} \; 2>/dev/null" "required"
check_item "无未使用的变量" "! grep -r 'local.*=.*-- unused' . --include='*.lua' 2>/dev/null | grep -q '.'" "optional"
check_item "代码注释率 > 20%" "find . -name '*.lua' -exec grep -c '^--' {} \; 2>/dev/null | awk '{sum+=\$1} END {if (NR>0 && sum/NR>0.2) exit 0; else exit 1}'" "optional"

# 3. 性能检查
echo -e "\n${BLUE}3. 性能检查${NC}"
echo "----------------------------------------"

check_item "无每帧重绘的Update循环" "! grep -r 'game:GetService(\"RunService\").RenderStepped:Connect' . --include='*.lua' 2>/dev/null | grep -q '.'" "required"
check_item "远程事件频率检查" "! grep -r 'RemoteEvent:FireServer()' . --include='*.lua' 2>/dev/null | grep -q 'while.*true'" "required"
check_item "内存泄漏检查" "! grep -r 'Instance.new().Parent = nil' . --include='*.lua' 2>/dev/null | grep -q '.'" "required"

# 4. 安全性检查
echo -e "\n${BLoxy}4. 安全性检查${NC}"
echo "----------------------------------------"

check_item "无硬编码密钥" "! grep -r 'API_KEY\|SECRET\|PASSWORD' . --include='*.lua' 2>/dev/null | grep -v 'test_key' | grep -q '.'" "required"
check_item "输入验证存在" "grep -r 'typeof\|assert\|error' . --include='*.lua' 2>/dev/null | grep -q 'check'" "optional"
check_item "防作弊基础机制" "grep -r 'AntiCheat\|Validation' . --include='*.lua' 2>/dev/null | grep -q '.'" "optional"

# 5. 内容检查
echo -e "\n${BLUE}5. 内容检查${NC}"
echo "----------------------------------------"

check_item "所有文本已本地化" "test -f Localization.csv || test -d Localization" "optional"
check_item "敏感内容已过滤" "test -f content-filter.txt || test -f moderation-list.txt" "optional"
check_item "年龄分级符合要求" "grep -q 'Suitable for all ages\|13+\|17+' *.txt 2>/dev/null" "required"

# 6. 测试检查
echo -e "\n${BLUE}6. 测试检查${NC}"
echo "----------------------------------------"

check_item "单元测试存在" "test -d tests || test -f test_*.lua" "optional"
check_item "集成测试通过" "test -f test-results.txt && grep -q 'PASS' test-results.txt" "optional"
check_item "性能测试完成" "test -f performance-report.txt" "optional"

# 7. 文档检查
echo -e "\n${BLUE}7. 文档检查${NC}"
echo "----------------------------------------"

check_item "API文档完整" "test -f API.md || test -f docs/API.md" "optional"
check_item "安装指南存在" "test -f INSTALL.md || grep -q 'installation\|setup' README.md 2>/dev/null" "optional"
check_item "故障排除指南" "test -f TROUBLESHOOTING.md || test -f FAQ.md" "optional"

# 8. 发布准备
echo -e "\n${BLUE}8. 发布准备检查${NC}"
echo "----------------------------------------"

check_item "商店页面已更新" "test -f store-page-update.txt || test -f marketing-notes.txt" "required"
check_item "社交媒体预告" "test -f social-media-posts.txt || test -f announcement-draft.txt" "optional"
check_item "社区公告准备" "test -f community-announcement.md || test -f discord-announcement.txt" "optional"
check_item "客服FAQ更新" "test -f support-faq-update.txt" "optional"
check_item "数据监控配置" "test -f analytics-config.txt || test -f metrics-dashboard.txt" "optional"
check_item "回滚方案准备" "test -f rollback-plan.txt" "required"

# 显示检查结果
echo -e "\n${BLUE}检查结果汇总${NC}"
echo "----------------------------------------"
echo -e "${GREEN}通过: $passed${NC}"
echo -e "${RED}失败: $failed${NC}"
echo -e "${YELLOW}警告: $warnings${NC}"
echo ""

if [ $failed -gt 0 ]; then
    echo -e "${RED}❌ 发布检查未通过！${NC}"
    echo "请修复所有必需项目（标记为'失败'的检查）后再尝试发布。"
    echo ""
    echo -e "${YELLOW}必需修复的项目：${NC}"
    # 这里可以添加逻辑显示具体哪些必需项目失败了
    exit 1
elif [ $warnings -gt 0 ]; then
    echo -e "${YELLOW}⚠️  发布检查通过，但有警告${NC}"
    echo "建议处理警告项目以提升发布质量。"
    echo ""
    echo -e "${GREEN}可以继续发布流程${NC}"
    exit 0
else
    echo -e "${GREEN}✅ 所有检查通过！${NC}"
    echo "发布检查完全通过，可以安全发布。"
    echo ""
    
    # 生成发布检查报告
    timestamp=$(date "+%Y-%m-%d %H:%M:%S")
    report_file="release-checklist-report-$(date +%Y%m%d-%H%M%S).txt"
    
    {
        echo "=== Roblox发布检查报告 ==="
        echo "检查时间: $timestamp"
        echo "项目路径: $(pwd)"
        echo "版本: $(grep -i version *.lua *.txt 2>/dev/null | head -1 || echo '未指定')"
        echo ""
        echo "检查结果:"
        echo "- 通过: $passed"
        echo "- 失败: $failed" 
        echo "- 警告: $warnings"
        echo ""
        echo "发布建议:"
        if [ $failed -eq 0 ] && [ $warnings -eq 0 ]; then
            echo "✅ 所有检查通过，可以安全发布"
        elif [ $failed -eq 0 ]; then
            echo "⚠️  检查通过但有警告，建议优化"
        else
            echo "❌ 有必需项目失败，请修复后再发布"
        fi
        echo ""
        echo "检查项目详情:"
        echo "1. 基础配置检查 - 完成"
        echo "2. 代码质量检查 - 完成" 
        echo "3. 性能检查 - 完成"
        echo "4. 安全性检查 - 完成"
        echo "5. 内容检查 - 完成"
        echo "6. 测试检查 - 完成"
        echo "7. 文档检查 - 完成"
        echo "8. 发布准备 - 完成"
    } > "$report_file"
    
    echo -e "报告已保存到: ${YELLOW}$report_file${NC}"
    echo ""
    echo -e "${GREEN}下一步：${NC}"
    echo "1. 备份当前版本"
    echo "2. 执行最终测试"
    echo "3. 更新商店页面"
    echo "4. 发布更新"
    echo "5. 监控发布后指标"
    
    exit 0
fi