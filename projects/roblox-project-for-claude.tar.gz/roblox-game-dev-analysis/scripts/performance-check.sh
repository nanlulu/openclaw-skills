#!/bin/bash
# Roblox游戏性能检查脚本
# 用于自动化分析Roblox游戏的性能问题

echo "=== Roblox游戏性能检查工具 ==="
echo "版本: 1.0.0"
echo ""

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 检查目录是否存在
if [ ! -d "." ]; then
    echo -e "${RED}错误：请在游戏项目根目录运行此脚本${NC}"
    exit 1
fi

# 1. 检查Lua脚本复杂度
echo -e "${BLUE}1. Lua脚本复杂度分析${NC}"
echo "----------------------------------------"

lua_files=$(find . -name "*.lua" -type f)
total_files=$(echo "$lua_files" | wc -l)
echo "找到 $total_files 个Lua文件"

if [ $total_files -gt 0 ]; then
    # 统计行数
    echo -e "\n${YELLOW}文件行数统计（前10名）：${NC}"
    echo "$lua_files" | xargs wc -l | sort -nr | head -11 | tail -10
    
    # 检查单个文件行数
    echo -e "\n${YELLOW}检查超大文件（>500行）：${NC}"
    find . -name "*.lua" -exec wc -l {} + | awk '$1 > 500 {print $1 " 行: " $2}' | sort -nr
    
    # 检查循环复杂度（简单版本）
    echo -e "\n${YELLOW}检查可能的高复杂度模式：${NC}"
    grep -r "for.*in.*pairs\|for.*in.*ipairs\|while.*do" . --include="*.lua" | wc -l | xargs echo "找到循环语句数量:"
fi

# 2. 内存使用检查
echo -e "\n${BLUE}2. 内存使用建议${NC}"
echo "----------------------------------------"
echo -e "${GREEN}Roblox内存限制：${NC}"
echo "- 低端设备：< 250MB"
echo "- 中端设备：< 500MB" 
echo "- 高端设备：< 1GB"
echo ""
echo -e "${YELLOW}优化建议：${NC}"
echo "1. 使用Texture Atlas减少纹理数量"
echo "2. 启用Mesh LOD（细节层次）"
echo "3. 优化粒子效果数量"
echo "4. 使用Instance pooling重用对象"

# 3. 网络优化检查
echo -e "\n${BLUE}3. 网络优化检查${NC}"
echo "----------------------------------------"
echo -e "${GREEN}网络性能指标：${NC}"
echo "- 远程事件频率：建议 < 10次/秒"
echo "- 数据包大小：建议 < 1KB"
echo "- Ping延迟：目标 < 200ms"
echo ""
echo -e "${YELLOW}同步策略建议：${NC}"
echo "1. 重要数据：状态同步（State replication）"
echo "2. 玩家输入：输入同步（Input replication）"
echo "3. 一次性事件：远程事件（Remote events）"
echo "4. 频繁更新：流式同步（Streaming）"

# 4. 渲染性能检查
echo -e "\n${BLUE}4. 渲染性能检查${NC}"
echo "----------------------------------------"
echo -e "${GREEN}渲染优化建议：${NC}"
echo "1. 三角形数量：移动端 < 50k，PC端 < 200k"
echo "2. 绘制调用：目标 < 100次/帧"
echo "3. 材质数量：尽量减少不同材质"
echo "4. 阴影：谨慎使用实时阴影"
echo ""
echo -e "${YELLOW}检查脚本：${NC}"
echo "在Roblox Studio中运行以下命令："
echo "1. 性能分析器：View → Performance Summary"
echo "2. 渲染统计：View → Statistics → Render"
echo "3. 网络模拟：Test → Simulation → Server/Client"

# 5. 脚本性能检查
echo -e "\n${BLUE}5. 脚本性能检查${NC}"
echo "----------------------------------------"
echo -e "${GREEN}常见性能问题：${NC}"
echo "1. 每帧运行的Update函数"
echo "2. 未缓存的FindFirstChild调用"
echo "3. 字符串连接在循环中"
echo "4. 未使用local变量"
echo ""
echo -e "${YELLOW}优化技巧：${NC}"
echo "1. 使用task.wait()而不是wait()"
echo "2. 缓存频繁访问的对象"
echo "3. 使用表代替字符串连接"
echo "4. 避免在渲染循环中创建新对象"

# 6. 生成报告
echo -e "\n${BLUE}6. 性能检查报告${NC}"
echo "----------------------------------------"
timestamp=$(date "+%Y-%m-%d %H:%M:%S")
echo "检查时间: $timestamp"
echo "项目路径: $(pwd)"
echo ""

# 检查结果总结
echo -e "${YELLOW}检查结果：${NC}"
if [ $total_files -eq 0 ]; then
    echo -e "${RED}⚠️  未找到Lua文件${NC}"
else
    echo -e "${GREEN}✓ 找到 $total_files 个Lua文件${NC}"
    
    # 检查是否有超大文件
    large_files=$(find . -name "*.lua" -exec wc -l {} + | awk '$1 > 1000' | wc -l)
    if [ $large_files -gt 0 ]; then
        echo -e "${RED}⚠️  发现 $large_files 个超过1000行的文件，建议拆分${NC}"
    else
        echo -e "${GREEN}✓ 没有发现超大文件${NC}"
    fi
fi

echo ""
echo -e "${BLUE}下一步行动：${NC}"
echo "1. 在Roblox Studio中运行性能分析器"
echo "2. 使用微配置文件优化热点代码"
echo "3. 在不同设备上测试性能"
echo "4. 设置性能监控和警报"

echo ""
echo -e "${GREEN}性能检查完成！${NC}"
echo "请根据建议优化您的游戏性能。"

# 保存报告到文件
report_file="performance-report-$(date +%Y%m%d-%H%M%S).txt"
{
    echo "=== Roblox性能检查报告 ==="
    echo "时间: $timestamp"
    echo "项目: $(pwd)"
    echo ""
    echo "Lua文件数量: $total_files"
    echo "超大文件数量: $large_files"
    echo ""
    echo "优化建议已生成"
} > "$report_file"

echo -e "\n报告已保存到: ${YELLOW}$report_file${NC}"