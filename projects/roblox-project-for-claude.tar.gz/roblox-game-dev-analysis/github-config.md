# GitHub 集成配置指南

## 1. 准备工作

### 1.1 创建GitHub仓库
1. 访问 https://github.com/new
2. 输入仓库名称：`roblox-game-dev-analysis`
3. 描述：`Roblox游戏开发分析工具包 - 基于爆款游戏成功经验`
4. 选择公开（Public）或私有（Private）
5. 不要初始化README、.gitignore或license（我们已有这些文件）
6. 点击"Create repository"

### 1.2 获取仓库信息
- 仓库URL：`https://github.com/你的用户名/roblox-game-dev-analysis`
- 仓库SSH：`git@github.com:你的用户名/roblox-game-dev-analysis.git`

## 2. 本地Git配置

### 2.1 初始化Git仓库
```bash
# 进入项目目录
cd /root/.openclaw/workspace/projects/roblox-game-dev-analysis

# 初始化Git
git init

# 添加所有文件
git add .

# 提交初始版本
git commit -m "初始提交：Roblox游戏开发分析工具包 v1.0"

# 添加远程仓库
git remote add origin https://github.com/你的用户名/roblox-game-dev-analysis.git

# 或者使用SSH
git remote add origin git@github.com:你的用户名/roblox-game-dev-analysis.git
```

### 2.2 配置Git用户信息
```bash
git config user.name "你的名字"
git config user.email "你的邮箱"
git config --global credential.helper store  # 保存凭据
```

## 3. GitHub Actions 配置

### 3.1 设置仓库Secrets
在GitHub仓库设置中，添加以下Secrets：

1. **GITHUB_TOKEN**（自动提供）
2. **TARGET_REPOSITORY**：`你的用户名/roblox-game-dev-analysis`
3. **TARGET_BRANCH**：`main`（默认）

### 3.2 启用Actions
1. 进入仓库的"Actions"标签页
2. 点击"Enable workflows"
3. 选择"Sync to GitHub Repository"工作流

## 4. 手动推送（第一次）

### 4.1 使用HTTPS（需要令牌）
```bash
# 生成Personal Access Token
# 访问：https://github.com/settings/tokens
# 选择权限：repo（全部）

# 推送代码
git push -u origin main
# 用户名：你的GitHub用户名
# 密码：你的Personal Access Token
```

### 4.2 使用SSH（推荐）
```bash
# 生成SSH密钥
ssh-keygen -t ed25519 -C "你的邮箱"

# 添加公钥到GitHub
# 访问：https://github.com/settings/keys
cat ~/.ssh/id_ed25519.pub

# 测试连接
ssh -T git@github.com

# 推送代码
git push -u origin main
```

## 5. 自动化同步

### 5.1 自动同步设置
项目已配置以下自动化：
- **手动触发**：通过GitHub Actions页面
- **定时同步**：每天UTC时间3:00（北京时间11:00）
- **推送触发**：当main分支有推送时

### 5.2 监控同步状态
1. 访问仓库的"Actions"标签页
2. 查看"Sync to GitHub Repository"工作流运行状态
3. 下载同步报告artifact

## 6. 项目结构验证

推送前验证项目结构：
```bash
# 检查文件结构
tree -I '.git|node_modules|__pycache__' -a

# 检查文件权限
find . -name "*.sh" -exec chmod +x {} \;

# 验证脚本
bash scripts/performance-check.sh --dry-run
bash scripts/pre-release-checklist.sh --dry-run
```

## 7. 故障排除

### 7.1 常见问题

**问题1：权限被拒绝**
```bash
# 解决方案：检查SSH密钥
ssh -T git@github.com
# 如果失败，重新添加SSH密钥
```

**问题2：大文件推送失败**
```bash
# 解决方案：使用Git LFS
git lfs install
git lfs track "*.psd" "*.zip" "*.mp4"
git add .gitattributes
```

**问题3：GitHub Actions失败**
- 检查Secrets配置是否正确
- 查看Actions日志详情
- 确保仓库名称格式正确：`username/repo`

### 7.2 测试连接
```bash
# 测试HTTPS连接
curl -I https://github.com/你的用户名/roblox-game-dev-analysis

# 测试SSH连接
ssh -T git@github.com

# 测试API访问
curl -H "Authorization: token YOUR_TOKEN" \
  https://api.github.com/user/repos
```

## 8. 后续维护

### 8.1 更新项目
```bash
# 拉取最新更改
git pull origin main

# 添加新文件
git add .

# 提交更改
git commit -m "更新：添加新功能/修复问题"

# 推送更改
git push origin main
```

### 8.2 版本管理
```bash
# 创建版本标签
git tag -a v1.0.0 -m "版本1.0.0：初始发布"
git push origin v1.0.0

# 查看版本历史
git log --oneline --graph --all
```

### 8.3 分支管理
```bash
# 创建功能分支
git checkout -b feature/new-analysis

# 开发完成后合并
git checkout main
git merge feature/new-analysis
git branch -d feature/new-analysis
```

## 9. 安全建议

1. **不要提交敏感信息**
   - API密钥、密码、私钥等
   - 使用`.gitignore`和`.env`文件

2. **定期更新依赖**
   ```bash
   # 检查安全漏洞
   npm audit
   pip-audit
   ```

3. **备份重要数据**
   - 定期导出数据库
   - 备份配置文件

## 10. 联系方式

- **问题反馈**：GitHub Issues
- **讨论区**：GitHub Discussions  
- **文档**：项目README.md
- **紧急联系**：通过GitHub Security Advisories

---

**最后更新**：2026-04-01  
**版本**：v1.0  
**维护者**：OpenClaw助手